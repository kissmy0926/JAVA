# [](https://github.com/kingyuluk/FlappyBird/compare/v1.2.2...v) (2020-08-06)



## [1.2.2](https://github.com/kingyuluk/FlappyBird/compare/v1.2.1...v1.2.2) (2020-07-14)


### Features

* 优化记分方法 ([33ad51a](https://github.com/kingyuluk/FlappyBird/commit/33ad51a97bcb6c2adce3fc944fa5aea00d210198))


### BREAKING CHANGES

* 移除了计时器，更改了游戏的记分方法，现在记分更准确了



## [1.2.1](https://github.com/kingyuluk/FlappyBird/compare/v1.2.0...v1.2.1) (2020-07-12)


### Features

* 更换音频播放方式 ([9429be6](https://github.com/kingyuluk/FlappyBird/commit/9429be613a21752d2c61e38ca7df87fb4a0b51b9))


### BREAKING CHANGES

* 使用AudioClip类的方法播放连续的短音频可能会导致线程冲突使游戏卡顿，改用sun.audio类的AudioPlayer方法播放音频



# [1.2.0](https://github.com/kingyuluk/FlappyBird/compare/v1.1.0...v1.2.0) (2020-07-11)


### Features

* 随机刷新可自行上下移动的水管 ([ab33686](https://github.com/kingyuluk/FlappyBird/commit/ab33686c8c2ace54da3ddffe220b40a33100989f))


### BREAKING CHANGES

* 移动型水管的刷新概率会随着当前游戏分数递增



# [1.1.0](https://github.com/kingyuluk/FlappyBird/compare/v1.0.0...v1.1.0) (2020-07-11)


### Features

* 添加悬浮型水管 ([074595b](https://github.com/kingyuluk/FlappyBird/commit/074595b3408a1323b41226d4b4259c6aff696888))



# [1.0.0](https://github.com/kingyuluk/FlappyBird/compare/d158fa5ca5927e1febcd460e8d61b5a16756c761...v1.0.0) (2020-07-09)


### Features

* 具备原版的游戏功能 ([d158fa5](https://github.com/kingyuluk/FlappyBird/commit/d158fa5ca5927e1febcd460e8d61b5a16756c761))
